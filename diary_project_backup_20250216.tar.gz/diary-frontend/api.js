import axios from 'axios';

const API_URL = 'http://localhost:8000/api/';

export const getDiaryEntries = async () => {
    return axios.get(`${API_URL}diary/`, { withCredentials: true });
};

export const postDiaryEntry = async (data) => {
    return axios.post(`${API_URL}diary/`, data, { withCredentials: true });
};

export const getTags = async () => {
    return axios.get(`${API_URL}tags/`, { withCredentials: true });
};
