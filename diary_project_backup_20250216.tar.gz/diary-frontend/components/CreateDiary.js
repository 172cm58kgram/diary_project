import React, { useState } from 'react';
import { postDiaryEntry } from '../api';

const CreateDiary = () => {
    const [content, setContent] = useState('');
    const [date, setDate] = useState('');
    const [image, setImage] = useState(null);

    const handleSubmit = async (e) => {
        e.preventDefault();
        const formData = new FormData();
        formData.append('content', content);
        formData.append('date', date);
        if (image) formData.append('image', image);

        await postDiaryEntry(formData);
        alert('日記を投稿しました！');
    };

    return (
        <form onSubmit={handleSubmit}>
            <input type="date" value={date} onChange={(e) => setDate(e.target.value)} required />
            <textarea value={content} onChange={(e) => setContent(e.target.value)} required />
            <input type="file" onChange={(e) => setImage(e.target.files[0])} />
            <button type="submit">投稿する</button>
        </form>
    );
};

export default CreateDiary;
