import React, { useEffect, useState } from 'react';
import { getDiaryEntries } from '../api';

const DiaryEntry = () => {
    const [entries, setEntries] = useState([]);

    useEffect(() => {
        getDiaryEntries().then(response => {
            setEntries(response.data);
        });
    }, []);

    return (
        <div>
            <h2>日記一覧</h2>
            {entries.map(entry => (
                <div key={entry.id}>
                    <h3>{entry.date}</h3>
                    <p>{entry.content}</p>
                    {entry.image && <img src={entry.image} alt="日記の画像" />}
                    <p>タグ: {entry.tags.map(tag => tag.name).join(', ')}</p>
                </div>
            ))}
        </div>
    );
};

export default DiaryEntry;
