from django.contrib import admin
from .models import DiaryEntry, Tag  # Tagもimport

# DiaryEntryを管理画面で表示できるように設定
class DiaryEntryAdmin(admin.ModelAdmin):
    list_display = ('title', 'user', 'date')  # 一覧画面で表示するフィールド
    search_fields = ('title', 'content', 'user__email')  # 検索可能なフィールド
    list_filter = ('date', 'tags')  # フィルタ可能なフィールド
    filter_horizontal = ('tags',)  # 🔹 多対多フィールドを管理画面で使いやすくする

# Tagモデルも管理画面に登録
admin.site.register(Tag)
admin.site.register(DiaryEntry, DiaryEntryAdmin)