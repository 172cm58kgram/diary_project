from diary.models import CustomUser
print(CustomUser.objects.all())